import ipaddress

def calculate_subnet_mask(ip, subnet_bits):
    network = ipaddress.IPv4Network(ip, strict=False)
    total_bits = network.prefixlen + subnet_bits
    if total_bits > 32:
        return "Invalid subnet bits"
    
    subnet_mask = str(ipaddress.IPv4Network(f'{ip}/{total_bits}', strict=False).netmask)
    return subnet_mask

def main():
    ip = input("Enter an IP address (e.g., 192.168.1.0/24): ")
    subnet_bits = int(input("Enter the number of bits for subnetting (e.g., 2): "))
    
    try:
        subnet_mask = calculate_subnet_mask(ip, subnet_bits)
        print(f"Calculated subnet mask: {subnet_mask}")
    except ValueError as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
